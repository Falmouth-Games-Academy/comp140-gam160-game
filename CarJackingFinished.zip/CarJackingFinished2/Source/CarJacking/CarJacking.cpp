// Fill out your copyright notice in the Description page of Project Settings.

#include "CarJacking.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CarJacking, "CarJacking" );
